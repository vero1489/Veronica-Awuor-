# Veronica Awuor Personal Website

A mobile-friendly personal portfolio website.

## Files
- index.html — website content
- style.css — design and responsive styling

## How to use on a phone
1. Extract the ZIP.
2. Open `index.html` in a browser to preview the site.
3. To publish it online, upload the files to a static website host such as GitHub Pages, Netlify, or another hosting service.

## Personal details
The site uses the contact details supplied for the portfolio draft. Edit `index.html` if you want to change them.
